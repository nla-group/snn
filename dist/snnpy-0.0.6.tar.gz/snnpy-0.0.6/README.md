## SNN: A lightweight fast exact radius query algorithm

### Install

Install the SNN package simply by


 ```python
    pip install snnpy
 ```